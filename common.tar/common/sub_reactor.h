/*************************************************************************
	> File Name: common/sub_reactor.h
	> Author: 
	> Mail: 
	> Created Time: Tue 09 Jun 2020 07:51:28 PM CST
 ************************************************************************/

#ifndef _SUB_REACTOR_H
#define _SUB_REACTOR_H
void *sub_reactor(void *arg);
#endif
