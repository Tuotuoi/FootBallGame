/*************************************************************************
	> File Name: test.c
	> Author: suyelu
	> Mail: suyelu@haizeix.com
	> Created Time: 日  3/29 18:58:15 2020
 ************************************************************************/

#include <stdio.h>
#include "color.h"

int main() {

    printf(YELLOW"ls"NONE"myls");
    return 0;
}
