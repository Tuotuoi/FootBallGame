/*************************************************************************
	> File Name: tcp_server.h
	> Author: suyelu
	> Mail: suyelu@haizeix.com
	> Created Time: 六  3/28 14:24:14 2020
 ************************************************************************/

#ifndef _TCP_SERVER_H
#define _TCP_SERVER_H
int socket_create_udp(int port);
#endif
