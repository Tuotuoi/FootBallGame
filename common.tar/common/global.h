/*************************************************************************
	> File Name: global.h
	> Author: 
	> Mail: 
	> Created Time: Thu 04 Jun 2020 07:31:15 PM CST
 ************************************************************************/

#ifndef _GLOBAL_H
#define _GLOBAL_H
extern char conf_ans[50];
#endif
